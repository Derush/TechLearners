package com.dreamon.techlearners.model;

public class UserResult {


}
